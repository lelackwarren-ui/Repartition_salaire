﻿namespace Repatition_salaire
{
    partial class Verification
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Verification));
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.idsalaireDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.salairenetDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.loyerDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.depensesDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.autresDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.transportDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.nourritureDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.resteDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dateDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.idnameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.salaireBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.database1DataSet3 = new Repatition_salaire.Database1DataSet3();
            this.csvbtn = new System.Windows.Forms.Button();
            this.Emailbtn = new System.Windows.Forms.Button();
            this.exit = new System.Windows.Forms.Button();
            this.titrelbl = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.restartbtn = new System.Windows.Forms.Button();
            this.Emailtxt = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.salaireTableAdapter = new Repatition_salaire.Database1DataSet3TableAdapters.salaireTableAdapter();
            this.label2 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.salaireBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.database1DataSet3)).BeginInit();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // dataGridView1
            // 
            this.dataGridView1.AutoGenerateColumns = false;
            this.dataGridView1.ClipboardCopyMode = System.Windows.Forms.DataGridViewClipboardCopyMode.Disable;
            this.dataGridView1.ColumnHeadersHeight = 34;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.idsalaireDataGridViewTextBoxColumn,
            this.salairenetDataGridViewTextBoxColumn,
            this.loyerDataGridViewTextBoxColumn,
            this.depensesDataGridViewTextBoxColumn,
            this.autresDataGridViewTextBoxColumn,
            this.transportDataGridViewTextBoxColumn,
            this.nourritureDataGridViewTextBoxColumn,
            this.resteDataGridViewTextBoxColumn,
            this.dateDataGridViewTextBoxColumn,
            this.idnameDataGridViewTextBoxColumn});
            this.dataGridView1.DataSource = this.salaireBindingSource;
            this.dataGridView1.Location = new System.Drawing.Point(-56, 84);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowHeadersWidth = 62;
            this.dataGridView1.RowTemplate.Height = 28;
            this.dataGridView1.Size = new System.Drawing.Size(1320, 120);
            this.dataGridView1.TabIndex = 0;
            // 
            // idsalaireDataGridViewTextBoxColumn
            // 
            this.idsalaireDataGridViewTextBoxColumn.DataPropertyName = "Idsalaire";
            this.idsalaireDataGridViewTextBoxColumn.HeaderText = "Idsalaire";
            this.idsalaireDataGridViewTextBoxColumn.MinimumWidth = 8;
            this.idsalaireDataGridViewTextBoxColumn.Name = "idsalaireDataGridViewTextBoxColumn";
            this.idsalaireDataGridViewTextBoxColumn.ReadOnly = true;
            this.idsalaireDataGridViewTextBoxColumn.Width = 150;
            // 
            // salairenetDataGridViewTextBoxColumn
            // 
            this.salairenetDataGridViewTextBoxColumn.DataPropertyName = "salairenet";
            this.salairenetDataGridViewTextBoxColumn.HeaderText = "Salaire Net";
            this.salairenetDataGridViewTextBoxColumn.MinimumWidth = 8;
            this.salairenetDataGridViewTextBoxColumn.Name = "salairenetDataGridViewTextBoxColumn";
            this.salairenetDataGridViewTextBoxColumn.Width = 150;
            // 
            // loyerDataGridViewTextBoxColumn
            // 
            this.loyerDataGridViewTextBoxColumn.DataPropertyName = "Loyer";
            this.loyerDataGridViewTextBoxColumn.HeaderText = "Loyer";
            this.loyerDataGridViewTextBoxColumn.MinimumWidth = 8;
            this.loyerDataGridViewTextBoxColumn.Name = "loyerDataGridViewTextBoxColumn";
            this.loyerDataGridViewTextBoxColumn.Width = 150;
            // 
            // depensesDataGridViewTextBoxColumn
            // 
            this.depensesDataGridViewTextBoxColumn.DataPropertyName = "Depenses";
            this.depensesDataGridViewTextBoxColumn.HeaderText = "Depenses";
            this.depensesDataGridViewTextBoxColumn.MinimumWidth = 8;
            this.depensesDataGridViewTextBoxColumn.Name = "depensesDataGridViewTextBoxColumn";
            this.depensesDataGridViewTextBoxColumn.Width = 150;
            // 
            // autresDataGridViewTextBoxColumn
            // 
            this.autresDataGridViewTextBoxColumn.DataPropertyName = "Autres";
            this.autresDataGridViewTextBoxColumn.HeaderText = "Autres";
            this.autresDataGridViewTextBoxColumn.MinimumWidth = 8;
            this.autresDataGridViewTextBoxColumn.Name = "autresDataGridViewTextBoxColumn";
            this.autresDataGridViewTextBoxColumn.Width = 150;
            // 
            // transportDataGridViewTextBoxColumn
            // 
            this.transportDataGridViewTextBoxColumn.DataPropertyName = "Transport";
            this.transportDataGridViewTextBoxColumn.HeaderText = "Transport";
            this.transportDataGridViewTextBoxColumn.MinimumWidth = 8;
            this.transportDataGridViewTextBoxColumn.Name = "transportDataGridViewTextBoxColumn";
            this.transportDataGridViewTextBoxColumn.Width = 150;
            // 
            // nourritureDataGridViewTextBoxColumn
            // 
            this.nourritureDataGridViewTextBoxColumn.DataPropertyName = "Nourriture";
            this.nourritureDataGridViewTextBoxColumn.HeaderText = "Nourriture";
            this.nourritureDataGridViewTextBoxColumn.MinimumWidth = 8;
            this.nourritureDataGridViewTextBoxColumn.Name = "nourritureDataGridViewTextBoxColumn";
            this.nourritureDataGridViewTextBoxColumn.Width = 150;
            // 
            // resteDataGridViewTextBoxColumn
            // 
            this.resteDataGridViewTextBoxColumn.DataPropertyName = "Reste";
            this.resteDataGridViewTextBoxColumn.HeaderText = "Reste";
            this.resteDataGridViewTextBoxColumn.MinimumWidth = 8;
            this.resteDataGridViewTextBoxColumn.Name = "resteDataGridViewTextBoxColumn";
            this.resteDataGridViewTextBoxColumn.Width = 150;
            // 
            // dateDataGridViewTextBoxColumn
            // 
            this.dateDataGridViewTextBoxColumn.DataPropertyName = "Date";
            this.dateDataGridViewTextBoxColumn.HeaderText = "Date";
            this.dateDataGridViewTextBoxColumn.MinimumWidth = 8;
            this.dateDataGridViewTextBoxColumn.Name = "dateDataGridViewTextBoxColumn";
            this.dateDataGridViewTextBoxColumn.Width = 150;
            // 
            // idnameDataGridViewTextBoxColumn
            // 
            this.idnameDataGridViewTextBoxColumn.DataPropertyName = "Idname";
            this.idnameDataGridViewTextBoxColumn.HeaderText = "Idname";
            this.idnameDataGridViewTextBoxColumn.MinimumWidth = 8;
            this.idnameDataGridViewTextBoxColumn.Name = "idnameDataGridViewTextBoxColumn";
            this.idnameDataGridViewTextBoxColumn.Width = 150;
            // 
            // salaireBindingSource
            // 
            this.salaireBindingSource.DataMember = "salaire";
            this.salaireBindingSource.DataSource = this.database1DataSet3;
            // 
            // database1DataSet3
            // 
            this.database1DataSet3.DataSetName = "Database1DataSet3";
            this.database1DataSet3.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // csvbtn
            // 
            this.csvbtn.BackColor = System.Drawing.Color.Lime;
            this.csvbtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.csvbtn.Location = new System.Drawing.Point(94, 317);
            this.csvbtn.Name = "csvbtn";
            this.csvbtn.Size = new System.Drawing.Size(212, 42);
            this.csvbtn.TabIndex = 1;
            this.csvbtn.Text = "CSV";
            this.csvbtn.UseVisualStyleBackColor = false;
            this.csvbtn.Click += new System.EventHandler(this.csvbtn_Click);
            // 
            // Emailbtn
            // 
            this.Emailbtn.BackColor = System.Drawing.Color.Yellow;
            this.Emailbtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Emailbtn.Location = new System.Drawing.Point(387, 317);
            this.Emailbtn.Name = "Emailbtn";
            this.Emailbtn.Size = new System.Drawing.Size(212, 42);
            this.Emailbtn.TabIndex = 2;
            this.Emailbtn.Text = "Envoyer E-mail";
            this.Emailbtn.UseVisualStyleBackColor = false;
            this.Emailbtn.Click += new System.EventHandler(this.Emailbtn_Click);
            // 
            // exit
            // 
            this.exit.BackColor = System.Drawing.Color.Red;
            this.exit.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.exit.Location = new System.Drawing.Point(1014, 317);
            this.exit.Name = "exit";
            this.exit.Size = new System.Drawing.Size(212, 42);
            this.exit.TabIndex = 4;
            this.exit.Text = "Exit";
            this.exit.UseVisualStyleBackColor = false;
            this.exit.Click += new System.EventHandler(this.exit_Click);
            // 
            // titrelbl
            // 
            this.titrelbl.AutoSize = true;
            this.titrelbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, ((System.Drawing.FontStyle)(((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic) 
                | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.titrelbl.Location = new System.Drawing.Point(478, 21);
            this.titrelbl.Name = "titrelbl";
            this.titrelbl.Size = new System.Drawing.Size(234, 29);
            this.titrelbl.TabIndex = 0;
            this.titrelbl.Text = "Répartition  salaire";
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.panel1.Controls.Add(this.titrelbl);
            this.panel1.Location = new System.Drawing.Point(0, 3);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1305, 75);
            this.panel1.TabIndex = 5;
            // 
            // restartbtn
            // 
            this.restartbtn.BackColor = System.Drawing.Color.Blue;
            this.restartbtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.restartbtn.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.restartbtn.Location = new System.Drawing.Point(1145, 396);
            this.restartbtn.Name = "restartbtn";
            this.restartbtn.Size = new System.Drawing.Size(138, 42);
            this.restartbtn.TabIndex = 6;
            this.restartbtn.Text = "Restart";
            this.restartbtn.UseVisualStyleBackColor = false;
            this.restartbtn.Click += new System.EventHandler(this.restartbtn_Click);
            // 
            // Emailtxt
            // 
            this.Emailtxt.BackColor = System.Drawing.Color.Teal;
            this.Emailtxt.Location = new System.Drawing.Point(527, 247);
            this.Emailtxt.Name = "Emailtxt";
            this.Emailtxt.Size = new System.Drawing.Size(490, 26);
            this.Emailtxt.TabIndex = 7;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(383, 250);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(74, 20);
            this.label1.TabIndex = 8;
            this.label1.Text = "E-mail : ";
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.button1.Location = new System.Drawing.Point(702, 317);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(212, 42);
            this.button1.TabIndex = 9;
            this.button1.Text = "Supprimer";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // salaireTableAdapter
            // 
            this.salaireTableAdapter.ClearBeforeFill = true;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(12, 401);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(271, 80);
            this.label2.TabIndex = 12;
            this.label2.Text = "Répartition salaire\r\nCopyright (c) 2026 Warren Kenji-LWK\r\n\r\nLicensed under the MI" +
    "T License.";
            // 
            // Verification
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.AliceBlue;
            this.ClientSize = new System.Drawing.Size(1295, 490);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.Emailtxt);
            this.Controls.Add(this.restartbtn);
            this.Controls.Add(this.exit);
            this.Controls.Add(this.Emailbtn);
            this.Controls.Add(this.csvbtn);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.panel1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Verification";
            this.Text = "Vérification";
            this.Load += new System.EventHandler(this.Verification_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.salaireBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.database1DataSet3)).EndInit();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Button csvbtn;
        private System.Windows.Forms.Button Emailbtn;
        private System.Windows.Forms.Button exit;
        private System.Windows.Forms.Label titrelbl;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button restartbtn;
        private System.Windows.Forms.TextBox Emailtxt;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button button1;
        private Database1DataSet3 database1DataSet3;
        private System.Windows.Forms.BindingSource salaireBindingSource;
        private Database1DataSet3TableAdapters.salaireTableAdapter salaireTableAdapter;
        private System.Windows.Forms.DataGridViewTextBoxColumn idsalaireDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn salairenetDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn loyerDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn depensesDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn autresDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn transportDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn nourritureDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn resteDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn dateDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn idnameDataGridViewTextBoxColumn;
        private System.Windows.Forms.Label label2;
    }
}