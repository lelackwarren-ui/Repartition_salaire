﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace Repatition_salaire
{
    public partial class add : Form
    {
        public add()
        {
            InitializeComponent();
        }

        private void add_Load(object sender, EventArgs e)
        {
            // TODO: cette ligne de code charge les données dans la table 'database1DataSet2.profil'. Vous pouvez la déplacer ou la supprimer selon les besoins.
            this.profilTableAdapter.Fill(this.database1DataSet2.profil);
            ChargerUtilisateur();
        }

        private void ChargerUtilisateur()
        {
            try
            {
                string databasePath = Path.Combine(Application.StartupPath, "Database1.mdf");

                string connectionString =
                $@"Data Source=(LocalDB)\MSSQLLocalDB;
AttachDbFilename={databasePath};
Integrated Security=True";
                SqlConnection con = new SqlConnection(connectionString);

                string requete =
                "SELECT Idname, pwd, name FROM profil WHERE Idname = @Idname";

                SqlCommand cmd = new SqlCommand(requete, con);

                cmd.Parameters.AddWithValue("@Idname", Login.IdProfilConnecte);

                SqlDataAdapter da = new SqlDataAdapter(cmd);

                DataTable dt = new DataTable();

                da.Fill(dt);

                profil.DataSource = dt;

                if (dt.Rows.Count > 0)
                {
                    idtxt.Text = dt.Rows[0]["Idname"].ToString();
                    pwdtxt.Text = dt.Rows[0]["pwd"].ToString();
                    nametxt.Text = dt.Rows[0]["name"].ToString();
                   
                }


                con.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                string databasePath = Path.Combine(Application.StartupPath, "Database1.mdf");

                string connectionString =
                $@"Data Source=(LocalDB)\MSSQLLocalDB;
AttachDbFilename={databasePath};
Integrated Security=True";
                SqlConnection con = new SqlConnection(connectionString);

                string requete = @"UPDATE profil
                       SET Name = @Name
                       WHERE Idname = @Idname";

                SqlCommand cmd = new SqlCommand(requete, con);

                cmd.Parameters.AddWithValue("@Name", nametxt.Text);
                cmd.Parameters.AddWithValue("@Idname", idtxt.Text);
                cmd.Parameters.AddWithValue("@pwd", pwdtxt.Text);

                con.Open();

                int resultat = cmd.ExecuteNonQuery();

                con.Close();

                if (resultat > 0)
                {
                    MessageBox.Show("Nom ajouté avec succès !");
                }
                else
                {
                    MessageBox.Show("Identifiant introuvable.");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Erreur : " + ex.Message);
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Application.Restart();
        }
    }
}
