﻿namespace Repatition_salaire
{
    partial class Login
    {
        /// <summary>
        /// Variable nécessaire au concepteur.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Nettoyage des ressources utilisées.
        /// </summary>
        /// <param name="disposing">true si les ressources managées doivent être supprimées ; sinon, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Code généré par le Concepteur Windows Form

        /// <summary>
        /// Méthode requise pour la prise en charge du concepteur - ne modifiez pas
        /// le contenu de cette méthode avec l'éditeur de code.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Login));
            this.Namelbl = new System.Windows.Forms.Label();
            this.pwdlbl = new System.Windows.Forms.Label();
            this.loginprofil = new System.Windows.Forms.PictureBox();
            this.panel1 = new System.Windows.Forms.Panel();
            this.titrelbl = new System.Windows.Forms.Label();
            this.idtxt = new System.Windows.Forms.TextBox();
            this.pwdtxt = new System.Windows.Forms.TextBox();
            this.loginbtn = new System.Windows.Forms.Button();
            this.resetbtn = new System.Windows.Forms.Button();
            this.exitbtn = new System.Windows.Forms.Button();
            this.changebtn = new System.Windows.Forms.Button();
            this.addbtn = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.loginprofil)).BeginInit();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // Namelbl
            // 
            this.Namelbl.AutoSize = true;
            this.Namelbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Namelbl.Location = new System.Drawing.Point(357, 154);
            this.Namelbl.Name = "Namelbl";
            this.Namelbl.Size = new System.Drawing.Size(119, 25);
            this.Namelbl.TabIndex = 0;
            this.Namelbl.Text = "Identifiant :";
            // 
            // pwdlbl
            // 
            this.pwdlbl.AutoSize = true;
            this.pwdlbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.pwdlbl.Location = new System.Drawing.Point(357, 225);
            this.pwdlbl.Name = "pwdlbl";
            this.pwdlbl.Size = new System.Drawing.Size(155, 25);
            this.pwdlbl.TabIndex = 1;
            this.pwdlbl.Text = "Mot de passe :";
            // 
            // loginprofil
            // 
            this.loginprofil.ErrorImage = ((System.Drawing.Image)(resources.GetObject("loginprofil.ErrorImage")));
            this.loginprofil.Image = ((System.Drawing.Image)(resources.GetObject("loginprofil.Image")));
            this.loginprofil.InitialImage = ((System.Drawing.Image)(resources.GetObject("loginprofil.InitialImage")));
            this.loginprofil.Location = new System.Drawing.Point(34, 133);
            this.loginprofil.Name = "loginprofil";
            this.loginprofil.Size = new System.Drawing.Size(225, 225);
            this.loginprofil.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.loginprofil.TabIndex = 2;
            this.loginprofil.TabStop = false;
            this.loginprofil.WaitOnLoad = true;
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.panel1.Controls.Add(this.titrelbl);
            this.panel1.Location = new System.Drawing.Point(-4, -8);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(883, 78);
            this.panel1.TabIndex = 3;
            // 
            // titrelbl
            // 
            this.titrelbl.AutoSize = true;
            this.titrelbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, ((System.Drawing.FontStyle)(((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic) 
                | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.titrelbl.Location = new System.Drawing.Point(332, 22);
            this.titrelbl.Name = "titrelbl";
            this.titrelbl.Size = new System.Drawing.Size(234, 29);
            this.titrelbl.TabIndex = 0;
            this.titrelbl.Text = "Répartition  salaire";
            // 
            // idtxt
            // 
            this.idtxt.BackColor = System.Drawing.Color.Teal;
            this.idtxt.Location = new System.Drawing.Point(566, 155);
            this.idtxt.Name = "idtxt";
            this.idtxt.Size = new System.Drawing.Size(182, 26);
            this.idtxt.TabIndex = 4;
            // 
            // pwdtxt
            // 
            this.pwdtxt.BackColor = System.Drawing.Color.Teal;
            this.pwdtxt.Location = new System.Drawing.Point(566, 224);
            this.pwdtxt.Name = "pwdtxt";
            this.pwdtxt.Size = new System.Drawing.Size(182, 26);
            this.pwdtxt.TabIndex = 5;
            // 
            // loginbtn
            // 
            this.loginbtn.BackColor = System.Drawing.Color.Lime;
            this.loginbtn.Location = new System.Drawing.Point(362, 301);
            this.loginbtn.Name = "loginbtn";
            this.loginbtn.Size = new System.Drawing.Size(86, 42);
            this.loginbtn.TabIndex = 6;
            this.loginbtn.Text = "Login";
            this.loginbtn.UseVisualStyleBackColor = false;
            this.loginbtn.Click += new System.EventHandler(this.loginbtn_Click);
            // 
            // resetbtn
            // 
            this.resetbtn.BackColor = System.Drawing.Color.Yellow;
            this.resetbtn.Location = new System.Drawing.Point(500, 301);
            this.resetbtn.Name = "resetbtn";
            this.resetbtn.Size = new System.Drawing.Size(79, 42);
            this.resetbtn.TabIndex = 7;
            this.resetbtn.Text = "Reset";
            this.resetbtn.UseVisualStyleBackColor = false;
            this.resetbtn.Click += new System.EventHandler(this.resetbtn_Click);
            // 
            // exitbtn
            // 
            this.exitbtn.BackColor = System.Drawing.Color.Red;
            this.exitbtn.Location = new System.Drawing.Point(743, 301);
            this.exitbtn.Name = "exitbtn";
            this.exitbtn.Size = new System.Drawing.Size(86, 42);
            this.exitbtn.TabIndex = 8;
            this.exitbtn.Text = "Exit";
            this.exitbtn.UseVisualStyleBackColor = false;
            // 
            // changebtn
            // 
            this.changebtn.BackColor = System.Drawing.Color.Blue;
            this.changebtn.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.changebtn.Location = new System.Drawing.Point(620, 409);
            this.changebtn.Name = "changebtn";
            this.changebtn.Size = new System.Drawing.Size(230, 60);
            this.changebtn.TabIndex = 9;
            this.changebtn.Text = "Changer de mot de passe";
            this.changebtn.UseVisualStyleBackColor = false;
            this.changebtn.Click += new System.EventHandler(this.changebtn_Click);
            // 
            // addbtn
            // 
            this.addbtn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.addbtn.Location = new System.Drawing.Point(620, 301);
            this.addbtn.Name = "addbtn";
            this.addbtn.Size = new System.Drawing.Size(86, 42);
            this.addbtn.TabIndex = 10;
            this.addbtn.Text = "Add";
            this.addbtn.UseVisualStyleBackColor = false;
            this.addbtn.Click += new System.EventHandler(this.add_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(12, 429);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(271, 80);
            this.label1.TabIndex = 11;
            this.label1.Text = "Répartition salaire\r\nCopyright (c) 2026 Warren Kenji-LWK\r\n\r\nLicensed under the MI" +
    "T License.";
            // 
            // Login
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(878, 519);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.addbtn);
            this.Controls.Add(this.changebtn);
            this.Controls.Add(this.exitbtn);
            this.Controls.Add(this.resetbtn);
            this.Controls.Add(this.loginbtn);
            this.Controls.Add(this.pwdtxt);
            this.Controls.Add(this.idtxt);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.loginprofil);
            this.Controls.Add(this.pwdlbl);
            this.Controls.Add(this.Namelbl);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Login";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Login";
            ((System.ComponentModel.ISupportInitialize)(this.loginprofil)).EndInit();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label Namelbl;
        private System.Windows.Forms.Label pwdlbl;
        private System.Windows.Forms.PictureBox loginprofil;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label titrelbl;
        private System.Windows.Forms.TextBox idtxt;
        private System.Windows.Forms.TextBox pwdtxt;
        private System.Windows.Forms.Button loginbtn;
        private System.Windows.Forms.Button resetbtn;
        private System.Windows.Forms.Button exitbtn;
        private System.Windows.Forms.Button changebtn;
        private System.Windows.Forms.Button addbtn;
        private System.Windows.Forms.Label label1;
    }
}

