﻿namespace Repatition_salaire
{
    partial class dashbord
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(dashbord));
            this.panel1 = new System.Windows.Forms.Panel();
            this.titrelbl = new System.Windows.Forms.Label();
            this.Calculebtn = new System.Windows.Forms.Button();
            this.salairelbl = new System.Windows.Forms.Label();
            this.loyerlbl = new System.Windows.Forms.Label();
            this.depenseslbl = new System.Windows.Forms.Label();
            this.Datelbl = new System.Windows.Forms.Label();
            this.autrelbl = new System.Windows.Forms.Label();
            this.Restelbl = new System.Windows.Forms.Label();
            this.salairetxt = new System.Windows.Forms.TextBox();
            this.loyertxt = new System.Windows.Forms.TextBox();
            this.depensetxt = new System.Windows.Forms.TextBox();
            this.datetxt = new System.Windows.Forms.TextBox();
            this.autre = new System.Windows.Forms.TextBox();
            this.restetxt = new System.Windows.Forms.TextBox();
            this.enregistrerbtn = new System.Windows.Forms.Button();
            this.Verifierbtn = new System.Windows.Forms.Button();
            this.transporttxt = new System.Windows.Forms.TextBox();
            this.Nourrituretxt = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.nomtxt = new System.Windows.Forms.TextBox();
            this.returnbtn = new System.Windows.Forms.Button();
            this.label4 = new System.Windows.Forms.Label();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.panel1.Controls.Add(this.titrelbl);
            this.panel1.Location = new System.Drawing.Point(1, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(798, 69);
            this.panel1.TabIndex = 4;
            // 
            // titrelbl
            // 
            this.titrelbl.AutoSize = true;
            this.titrelbl.BackColor = System.Drawing.Color.Transparent;
            this.titrelbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, ((System.Drawing.FontStyle)(((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic) 
                | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.titrelbl.Location = new System.Drawing.Point(261, 9);
            this.titrelbl.Name = "titrelbl";
            this.titrelbl.Size = new System.Drawing.Size(234, 29);
            this.titrelbl.TabIndex = 0;
            this.titrelbl.Text = "Répartition  salaire";
            // 
            // Calculebtn
            // 
            this.Calculebtn.BackColor = System.Drawing.Color.Lime;
            this.Calculebtn.Location = new System.Drawing.Point(68, 359);
            this.Calculebtn.Name = "Calculebtn";
            this.Calculebtn.Size = new System.Drawing.Size(109, 37);
            this.Calculebtn.TabIndex = 5;
            this.Calculebtn.Text = "Calculer";
            this.Calculebtn.UseVisualStyleBackColor = false;
            this.Calculebtn.Click += new System.EventHandler(this.Calculebtn_Click);
            // 
            // salairelbl
            // 
            this.salairelbl.AutoSize = true;
            this.salairelbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.salairelbl.Location = new System.Drawing.Point(69, 178);
            this.salairelbl.Name = "salairelbl";
            this.salairelbl.Size = new System.Drawing.Size(108, 20);
            this.salairelbl.TabIndex = 6;
            this.salairelbl.Text = "Salaire Net :";
            // 
            // loyerlbl
            // 
            this.loyerlbl.AutoSize = true;
            this.loyerlbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.loyerlbl.Location = new System.Drawing.Point(69, 229);
            this.loyerlbl.Name = "loyerlbl";
            this.loyerlbl.Size = new System.Drawing.Size(63, 20);
            this.loyerlbl.TabIndex = 7;
            this.loyerlbl.Text = "Loyer :";
            // 
            // depenseslbl
            // 
            this.depenseslbl.AutoSize = true;
            this.depenseslbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.depenseslbl.Location = new System.Drawing.Point(69, 275);
            this.depenseslbl.Name = "depenseslbl";
            this.depenseslbl.Size = new System.Drawing.Size(100, 20);
            this.depenseslbl.TabIndex = 8;
            this.depenseslbl.Text = "Dépenses :";
            // 
            // Datelbl
            // 
            this.Datelbl.AutoSize = true;
            this.Datelbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Datelbl.Location = new System.Drawing.Point(421, 101);
            this.Datelbl.Name = "Datelbl";
            this.Datelbl.Size = new System.Drawing.Size(58, 20);
            this.Datelbl.TabIndex = 9;
            this.Datelbl.Text = "Date :";
            // 
            // autrelbl
            // 
            this.autrelbl.AutoSize = true;
            this.autrelbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.autrelbl.Location = new System.Drawing.Point(407, 223);
            this.autrelbl.Name = "autrelbl";
            this.autrelbl.Size = new System.Drawing.Size(72, 20);
            this.autrelbl.TabIndex = 10;
            this.autrelbl.Text = "Autres :";
            // 
            // Restelbl
            // 
            this.Restelbl.AutoSize = true;
            this.Restelbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Restelbl.Location = new System.Drawing.Point(407, 275);
            this.Restelbl.Name = "Restelbl";
            this.Restelbl.Size = new System.Drawing.Size(152, 20);
            this.Restelbl.TabIndex = 11;
            this.Restelbl.Text = "Reste (Epargne) :";
            // 
            // salairetxt
            // 
            this.salairetxt.Location = new System.Drawing.Point(183, 181);
            this.salairetxt.Name = "salairetxt";
            this.salairetxt.Size = new System.Drawing.Size(159, 26);
            this.salairetxt.TabIndex = 12;
            // 
            // loyertxt
            // 
            this.loyertxt.Location = new System.Drawing.Point(183, 226);
            this.loyertxt.Name = "loyertxt";
            this.loyertxt.Size = new System.Drawing.Size(159, 26);
            this.loyertxt.TabIndex = 13;
            // 
            // depensetxt
            // 
            this.depensetxt.Location = new System.Drawing.Point(183, 275);
            this.depensetxt.Name = "depensetxt";
            this.depensetxt.Size = new System.Drawing.Size(159, 26);
            this.depensetxt.TabIndex = 14;
            // 
            // datetxt
            // 
            this.datetxt.Location = new System.Drawing.Point(577, 98);
            this.datetxt.Name = "datetxt";
            this.datetxt.Size = new System.Drawing.Size(162, 26);
            this.datetxt.TabIndex = 15;
            // 
            // autre
            // 
            this.autre.Location = new System.Drawing.Point(580, 220);
            this.autre.Name = "autre";
            this.autre.Size = new System.Drawing.Size(162, 26);
            this.autre.TabIndex = 16;
            // 
            // restetxt
            // 
            this.restetxt.Location = new System.Drawing.Point(580, 275);
            this.restetxt.Name = "restetxt";
            this.restetxt.Size = new System.Drawing.Size(162, 26);
            this.restetxt.TabIndex = 17;
            // 
            // enregistrerbtn
            // 
            this.enregistrerbtn.BackColor = System.Drawing.Color.Yellow;
            this.enregistrerbtn.Location = new System.Drawing.Point(335, 359);
            this.enregistrerbtn.Name = "enregistrerbtn";
            this.enregistrerbtn.Size = new System.Drawing.Size(109, 37);
            this.enregistrerbtn.TabIndex = 18;
            this.enregistrerbtn.Text = "Enregistrer ";
            this.enregistrerbtn.UseVisualStyleBackColor = false;
            this.enregistrerbtn.Click += new System.EventHandler(this.enregistrerbtn_Click);
            // 
            // Verifierbtn
            // 
            this.Verifierbtn.BackColor = System.Drawing.Color.Red;
            this.Verifierbtn.Location = new System.Drawing.Point(577, 359);
            this.Verifierbtn.Name = "Verifierbtn";
            this.Verifierbtn.Size = new System.Drawing.Size(109, 37);
            this.Verifierbtn.TabIndex = 19;
            this.Verifierbtn.Text = "Vérifier";
            this.Verifierbtn.UseVisualStyleBackColor = false;
            this.Verifierbtn.Click += new System.EventHandler(this.Verifierbtn_Click);
            // 
            // transporttxt
            // 
            this.transporttxt.Location = new System.Drawing.Point(183, 327);
            this.transporttxt.Name = "transporttxt";
            this.transporttxt.Size = new System.Drawing.Size(159, 26);
            this.transporttxt.TabIndex = 20;
            // 
            // Nourrituretxt
            // 
            this.Nourrituretxt.Location = new System.Drawing.Point(580, 175);
            this.Nourrituretxt.Name = "Nourrituretxt";
            this.Nourrituretxt.Size = new System.Drawing.Size(159, 26);
            this.Nourrituretxt.TabIndex = 21;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(407, 181);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(99, 20);
            this.label1.TabIndex = 22;
            this.label1.Text = "Nourriture :";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(69, 327);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(96, 20);
            this.label2.TabIndex = 23;
            this.label2.Text = "Transport :";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(99, 101);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(55, 20);
            this.label3.TabIndex = 24;
            this.label3.Text = "Nom :";
            // 
            // nomtxt
            // 
            this.nomtxt.Location = new System.Drawing.Point(183, 101);
            this.nomtxt.Name = "nomtxt";
            this.nomtxt.Size = new System.Drawing.Size(159, 26);
            this.nomtxt.TabIndex = 25;
            // 
            // returnbtn
            // 
            this.returnbtn.BackColor = System.Drawing.Color.Blue;
            this.returnbtn.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.returnbtn.Location = new System.Drawing.Point(679, 411);
            this.returnbtn.Name = "returnbtn";
            this.returnbtn.Size = new System.Drawing.Size(109, 37);
            this.returnbtn.TabIndex = 26;
            this.returnbtn.Text = "Revenir";
            this.returnbtn.UseVisualStyleBackColor = false;
            this.returnbtn.Click += new System.EventHandler(this.returnbtn_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(12, 452);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(271, 80);
            this.label4.TabIndex = 27;
            this.label4.Text = "Répartition salaire\r\nCopyright (c) 2026 Warren Kenji-LWK\r\n\r\nLicensed under the MI" +
    "T License.";
            // 
            // dashbord
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 541);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.returnbtn);
            this.Controls.Add(this.nomtxt);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.Nourrituretxt);
            this.Controls.Add(this.transporttxt);
            this.Controls.Add(this.Verifierbtn);
            this.Controls.Add(this.enregistrerbtn);
            this.Controls.Add(this.restetxt);
            this.Controls.Add(this.autre);
            this.Controls.Add(this.datetxt);
            this.Controls.Add(this.depensetxt);
            this.Controls.Add(this.loyertxt);
            this.Controls.Add(this.salairetxt);
            this.Controls.Add(this.Restelbl);
            this.Controls.Add(this.autrelbl);
            this.Controls.Add(this.Datelbl);
            this.Controls.Add(this.depenseslbl);
            this.Controls.Add(this.loyerlbl);
            this.Controls.Add(this.salairelbl);
            this.Controls.Add(this.Calculebtn);
            this.Controls.Add(this.panel1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "dashbord";
            this.Text = "Réparition salaire";
            this.Load += new System.EventHandler(this.dashbord_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label titrelbl;
        private System.Windows.Forms.Button Calculebtn;
        private System.Windows.Forms.Label salairelbl;
        private System.Windows.Forms.Label loyerlbl;
        private System.Windows.Forms.Label depenseslbl;
        private System.Windows.Forms.Label Datelbl;
        private System.Windows.Forms.Label autrelbl;
        private System.Windows.Forms.Label Restelbl;
        private System.Windows.Forms.TextBox salairetxt;
        private System.Windows.Forms.TextBox loyertxt;
        private System.Windows.Forms.TextBox depensetxt;
        private System.Windows.Forms.TextBox datetxt;
        private System.Windows.Forms.TextBox autre;
        private System.Windows.Forms.TextBox restetxt;
        private System.Windows.Forms.Button enregistrerbtn;
        private System.Windows.Forms.Button Verifierbtn;
        private System.Windows.Forms.TextBox transporttxt;
        private System.Windows.Forms.TextBox Nourrituretxt;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox nomtxt;
        private System.Windows.Forms.Button returnbtn;
        private System.Windows.Forms.Label label4;
    }
}