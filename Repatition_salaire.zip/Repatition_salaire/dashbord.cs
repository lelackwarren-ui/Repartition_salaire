﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
namespace Repatition_salaire
{
    public partial class dashbord : Form
    {
        public dashbord()
        {
            InitializeComponent();
        }
        
        private void dashbord_Load(object sender, EventArgs e)
        {
            ChargerUtilisateur();
        }

        private void ChargerUtilisateur()
        {
            try
            {
                string databasePath = Path.Combine(Application.StartupPath, "Database1.mdf");

                string connectionString =
                $@"Data Source=(LocalDB)\MSSQLLocalDB;
AttachDbFilename={databasePath};
Integrated Security=True";
                SqlConnection con = new SqlConnection(connectionString);

                string requete =
                "SELECT name FROM profil WHERE Idname = @Idname";

                SqlCommand cmd = new SqlCommand(requete, con);

                cmd.Parameters.AddWithValue("@Idname", Login.IdProfilConnecte);

                SqlDataAdapter da = new SqlDataAdapter(cmd);

                DataTable dt = new DataTable();

                da.Fill(dt);

                nomtxt.Text = dt.Rows[0]["name"].ToString();

                con.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void Calculebtn_Click(object sender, EventArgs e)
        {
            try
            {
                decimal salaire = Convert.ToDecimal(salairetxt.Text);
                decimal loyer = Convert.ToDecimal(loyertxt.Text);
                decimal depenses = Convert.ToDecimal(depensetxt.Text);
                decimal transport = Convert.ToDecimal(transporttxt.Text);
                decimal nourriture = Convert.ToDecimal(Nourrituretxt.Text);
                decimal autres = Convert.ToDecimal(autre.Text);

                decimal reste = salaire - loyer - depenses - transport - nourriture - autres;

                restetxt.Text = reste.ToString();
            }
            catch
            {
                MessageBox.Show("Veuillez saisir uniquement des nombres.");
            }

        }

        private void enregistrerbtn_Click(object sender, EventArgs e)
        {
            try
            {
                string databasePath = Path.Combine(Application.StartupPath, "Database1.mdf");

                string connectionString =
                $@"Data Source=(LocalDB)\MSSQLLocalDB;
AttachDbFilename={databasePath};
Integrated Security=True";
                using (SqlConnection con = new SqlConnection(connectionString))
                {
                    con.Open();

                    string requete = @"INSERT INTO salaire
            (Idname, Date, salairenet, Loyer,
             Depenses, Transport, Nourriture, Autres, Reste)

            VALUES
            (@Idname, @Date, @salairenet, @Loyer,
             @Depenses, @Transport, @Nourriture, @Autres, @Reste)";

                    SqlCommand cmd = new SqlCommand(requete, con);

                    cmd.Parameters.AddWithValue("@Idname", Login.IdProfilConnecte);
                    cmd.Parameters.AddWithValue("@Date", DateTime.Now);
                    cmd.Parameters.AddWithValue("@salairenet", salairetxt.Text);
                    cmd.Parameters.AddWithValue("@Loyer", loyertxt.Text);
                    cmd.Parameters.AddWithValue("@Depenses", depensetxt.Text);
                    cmd.Parameters.AddWithValue("@Transport", transporttxt.Text);
                    cmd.Parameters.AddWithValue("@Nourriture", Nourrituretxt.Text);
                    cmd.Parameters.AddWithValue("@Autres", autre.Text);
                    cmd.Parameters.AddWithValue("@Reste", restetxt.Text);

                    cmd.ExecuteNonQuery();

                    MessageBox.Show("Enregistrement réussi !");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void Verifierbtn_Click(object sender, EventArgs e)
        {
            Verification verifier = new Verification();
            this.Hide();
            verifier.Show();
        }

        private void returnbtn_Click(object sender, EventArgs e)
        {
            Login login = new Login();
            this.Hide();
            login.Show();
        }

        
    }
}
