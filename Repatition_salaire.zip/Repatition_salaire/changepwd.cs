﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace Repatition_salaire
{
    public partial class changepwd : Form
    {
        public changepwd()
        {
            InitializeComponent();
        }

        private void ChargerUtilisateur()
        {
            try
            {
                string databasePath = Path.Combine(Application.StartupPath, "Database1.mdf");

                string connectionString =
                $@"Data Source=(LocalDB)\MSSQLLocalDB;
AttachDbFilename={databasePath};
Integrated Security=True";
                SqlConnection con = new SqlConnection(connectionString);

                string requete =
                "SELECT Idname, pwd, name FROM Profil WHERE Idname = @Idname";

                SqlCommand cmd = new SqlCommand(requete, con);

                cmd.Parameters.AddWithValue("@Idname", Login.IdProfilConnecte);

                SqlDataAdapter da = new SqlDataAdapter(cmd);

                DataTable dt = new DataTable();

                da.Fill(dt);

                dataGridView1.DataSource = dt;

                if (dt.Rows.Count > 0)
                {
                    idtxt.Text = dt.Rows[0]["Idname"].ToString();
                    pwdtxt.Text = dt.Rows[0]["pwd"].ToString();
                    nametxt.Text = dt.Rows[0]["name"].ToString();
                    
                }

                con.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void changepwd_Load(object sender, EventArgs e)
        {
            // TODO: cette ligne de code charge les données dans la table 'database1DataSet1.profil'. Vous pouvez la déplacer ou la supprimer selon les besoins.
            this.profilTableAdapter.Fill(this.database1DataSet1.profil);
            ChargerUtilisateur();
        }

        private void modifierbtn_Click(object sender, EventArgs e)
        {
            try
            {
                string databasePath = Path.Combine(Application.StartupPath, "Database1.mdf");

                string connectionString =
                $@"Data Source=(LocalDB)\MSSQLLocalDB;
AttachDbFilename={databasePath};
Integrated Security=True";
                SqlConnection con = new SqlConnection(connectionString);

                string requete =
                "UPDATE profil SET pwd=@pwd WHERE Idname=@Idname";

                SqlCommand cmd = new SqlCommand(requete, con);

                cmd.Parameters.AddWithValue("@pwd", pwdtxt.Text);
                cmd.Parameters.AddWithValue("@Idname", idtxt.Text);

                con.Open();
                cmd.ExecuteNonQuery();
                con.Close();

                MessageBox.Show("Mot de passe modifié avec succès.");

                ChargerUtilisateur();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Application.Restart();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            DialogResult reponse = MessageBox.Show(
                  "Voulez-vous vraiment supprimer cette ligne ?",
                   "Confirmation",
                  MessageBoxButtons.YesNo,
                 MessageBoxIcon.Question);

            if (reponse == DialogResult.Yes)
            {
                try
                {
                    if (dataGridView1.CurrentRow != null)
                    {
                        string idname = Convert.ToString(
                            dataGridView1.CurrentRow.Cells["Idname"].Value);

                        string databasePath = Path.Combine(Application.StartupPath, "Database1.mdf");

                        string connectionString =
                        $@"Data Source=(LocalDB)\MSSQLLocalDB;
AttachDbFilename={databasePath};
Integrated Security=True";

                        SqlConnection con = new SqlConnection(connectionString);

                        string requete =
                            "DELETE * FROM profil WHERE Idname = @Idname";

                        SqlCommand cmd = new SqlCommand(requete, con);

                        cmd.Parameters.AddWithValue("@Idname", Login.IdProfilConnecte);

                        con.Open();

                        int resultat = cmd.ExecuteNonQuery();

                        con.Close();

                        if (resultat > 0)
                        {
                            MessageBox.Show("Enregistrement supprimé avec succès.");

                            ChargerUtilisateur(); // Recharge le DataGridView
                        }
                        else
                        {
                            MessageBox.Show("Suppression impossible.");
                        }
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
        }
    }

}
