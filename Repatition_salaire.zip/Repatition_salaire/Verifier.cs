﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Net;
using System.Net.Mail;


namespace Repatition_salaire
{
    public partial class Verification : Form
    {
        public Verification()
        {
            InitializeComponent();
            ChargerDonnees();
        }

        

        private void ChargerDonnees()
        {
            try
            {
                string databasePath = Path.Combine(Application.StartupPath, "Database1.mdf");

                string connectionString =
                $@"Data Source=(LocalDB)\MSSQLLocalDB;
AttachDbFilename={databasePath};
Integrated Security=True";

                using (SqlConnection con = new SqlConnection(connectionString))
                {
                    string requete = @" SELECT * FROM salaire WHERE Idname = @Idname";

                    SqlCommand cmd = new SqlCommand(requete, con);

                    cmd.Parameters.AddWithValue("@Idname", Login.IdProfilConnecte);

                    SqlDataAdapter da = new SqlDataAdapter(cmd);

                    DataTable dt = new DataTable();

                    da.Fill(dt);

                    
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
        private void csvbtn_Click(object sender, EventArgs e)
        {
            SaveFileDialog save = new SaveFileDialog();

            save.Filter = "CSV files (*.csv)|*.csv";

            if (save.ShowDialog() == DialogResult.OK)
            {
                using (StreamWriter sw = new StreamWriter(save.FileName))
                {
                    // Colonnes
                    for (int i = 0; i < dataGridView1.Columns.Count; i++)
                    {
                        sw.Write(dataGridView1.Columns[i].HeaderText);

                        if (i < dataGridView1.Columns.Count - 1)
                            sw.Write(";");
                    }
                    sw.WriteLine();

                    // Lignes
                    foreach (DataGridViewRow row in dataGridView1.Rows)
                    {
                        if (!row.IsNewRow)
                        {
                            for (int i = 0; i < dataGridView1.Columns.Count; i++)
                            {
                                sw.Write(row.Cells[i].Value);

                                if (i < dataGridView1.Columns.Count - 1)
                                    sw.Write(";");
                            }

                            sw.WriteLine();
                        }
                    }
                }

                MessageBox.Show("Fichier CSV créé avec succès.");
            }
        }

                

        private void Emailbtn_Click(object sender, EventArgs e)
        {
            try
            {
                MailMessage mail = new MailMessage();

                mail.From = new MailAddress("lelackwarre@gmail.com");
                mail.To.Add(Emailtxt.Text);

                mail.Subject = "Répartition salaire";
                mail.Body = "Bonjour,\nVeuillez trouver vos informations de salaire.";

                SmtpClient smtp = new SmtpClient("smtp.gmail.com", 587);

                smtp.Credentials =
                    new NetworkCredential(
                        "tonadresse@gmail.com",
                        "mot_de_passe_application");

                smtp.EnableSsl = true;

                smtp.Send(mail);

                MessageBox.Show("E-mail envoyé avec succès.");
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            DialogResult reponse = MessageBox.Show(
                     "Voulez-vous vraiment supprimer cette ligne ?",
                      "Confirmation",
                     MessageBoxButtons.YesNo,
                    MessageBoxIcon.Question);

            if (reponse == DialogResult.Yes)
            {
                try
                {
                    if (dataGridView1.CurrentRow != null)
                    {
                    int idSalaire = Convert.ToInt32(
                        dataGridView1.CurrentRow.Cells["Idsalaire"].Value);

                        string databasePath = Path.Combine(Application.StartupPath, "Database1.mdf");

                        string connectionString =
                        $@"Data Source=(LocalDB)\MSSQLLocalDB;
AttachDbFilename={databasePath};
Integrated Security=True";

                        SqlConnection con = new SqlConnection(connectionString);

                    string requete =
                        "DELETE FROM salaire WHERE Idsalaire = @Idsalaire";

                    SqlCommand cmd = new SqlCommand(requete, con);

                    cmd.Parameters.AddWithValue("@Idsalaire", idSalaire);

                    con.Open();

                    int resultat = cmd.ExecuteNonQuery();

                    con.Close();

                    if (resultat > 0)
                    {
                        MessageBox.Show("Enregistrement supprimé avec succès.");

                        ChargerDonnees(); // Recharge le DataGridView
                    }
                    else
                    {
                        MessageBox.Show("Suppression impossible.");
                    }
                }
            }
    catch (Exception ex)
    {
                MessageBox.Show(ex.Message);
            }
        }
        }

       

        private void exit_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void restartbtn_Click(object sender, EventArgs e)
        {
            Application.Restart();
        }

        private void Verification_Load(object sender, EventArgs e)
        {
            // TODO: cette ligne de code charge les données dans la table 'database1DataSet3.salaire'. Vous pouvez la déplacer ou la supprimer selon les besoins.
            this.salaireTableAdapter.Fill(this.database1DataSet3.salaire);

        }
    }
}
