﻿namespace Repatition_salaire
{
    partial class add
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(add));
            this.titrelbl = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.idtxt = new System.Windows.Forms.TextBox();
            this.pwdtxt = new System.Windows.Forms.TextBox();
            this.nametxt = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.profil = new System.Windows.Forms.DataGridView();
            this.idnameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.pwdDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.nameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.profilBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.database1DataSet2 = new Repatition_salaire.Database1DataSet2();
            this.button2 = new System.Windows.Forms.Button();
            this.profilTableAdapter = new Repatition_salaire.Database1DataSet2TableAdapters.profilTableAdapter();
            this.label4 = new System.Windows.Forms.Label();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.profil)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.profilBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.database1DataSet2)).BeginInit();
            this.SuspendLayout();
            // 
            // titrelbl
            // 
            this.titrelbl.AutoSize = true;
            this.titrelbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, ((System.Drawing.FontStyle)(((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic) 
                | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.titrelbl.Location = new System.Drawing.Point(277, 15);
            this.titrelbl.Name = "titrelbl";
            this.titrelbl.Size = new System.Drawing.Size(234, 29);
            this.titrelbl.TabIndex = 0;
            this.titrelbl.Text = "Répartition  salaire";
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.panel1.Controls.Add(this.titrelbl);
            this.panel1.Location = new System.Drawing.Point(1, -1);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(798, 73);
            this.panel1.TabIndex = 7;
            // 
            // idtxt
            // 
            this.idtxt.BackColor = System.Drawing.Color.Teal;
            this.idtxt.Location = new System.Drawing.Point(221, 180);
            this.idtxt.Name = "idtxt";
            this.idtxt.Size = new System.Drawing.Size(227, 26);
            this.idtxt.TabIndex = 19;
            // 
            // pwdtxt
            // 
            this.pwdtxt.BackColor = System.Drawing.Color.Teal;
            this.pwdtxt.Location = new System.Drawing.Point(221, 265);
            this.pwdtxt.Name = "pwdtxt";
            this.pwdtxt.Size = new System.Drawing.Size(227, 26);
            this.pwdtxt.TabIndex = 18;
            // 
            // nametxt
            // 
            this.nametxt.BackColor = System.Drawing.Color.Teal;
            this.nametxt.Location = new System.Drawing.Point(221, 350);
            this.nametxt.Name = "nametxt";
            this.nametxt.Size = new System.Drawing.Size(227, 26);
            this.nametxt.TabIndex = 17;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(85, 356);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(55, 20);
            this.label3.TabIndex = 16;
            this.label3.Text = "Nom :";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(85, 271);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(127, 20);
            this.label2.TabIndex = 15;
            this.label2.Text = "Mot de passe :";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(85, 186);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(101, 20);
            this.label1.TabIndex = 14;
            this.label1.Text = "Identifiant :";
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.Lime;
            this.button1.Location = new System.Drawing.Point(546, 246);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(170, 70);
            this.button1.TabIndex = 13;
            this.button1.Text = "Ajouter";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // profil
            // 
            this.profil.AutoGenerateColumns = false;
            this.profil.ColumnHeadersHeight = 34;
            this.profil.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.idnameDataGridViewTextBoxColumn,
            this.pwdDataGridViewTextBoxColumn,
            this.nameDataGridViewTextBoxColumn});
            this.profil.DataSource = this.profilBindingSource;
            this.profil.Location = new System.Drawing.Point(42, 83);
            this.profil.Name = "profil";
            this.profil.RowHeadersWidth = 62;
            this.profil.RowTemplate.Height = 28;
            this.profil.Size = new System.Drawing.Size(700, 100);
            this.profil.TabIndex = 12;
            // 
            // idnameDataGridViewTextBoxColumn
            // 
            this.idnameDataGridViewTextBoxColumn.DataPropertyName = "Idname";
            this.idnameDataGridViewTextBoxColumn.HeaderText = "Idname";
            this.idnameDataGridViewTextBoxColumn.MinimumWidth = 8;
            this.idnameDataGridViewTextBoxColumn.Name = "idnameDataGridViewTextBoxColumn";
            this.idnameDataGridViewTextBoxColumn.Width = 150;
            // 
            // pwdDataGridViewTextBoxColumn
            // 
            this.pwdDataGridViewTextBoxColumn.DataPropertyName = "pwd";
            this.pwdDataGridViewTextBoxColumn.HeaderText = "Pwd";
            this.pwdDataGridViewTextBoxColumn.MinimumWidth = 8;
            this.pwdDataGridViewTextBoxColumn.Name = "pwdDataGridViewTextBoxColumn";
            this.pwdDataGridViewTextBoxColumn.Width = 150;
            // 
            // nameDataGridViewTextBoxColumn
            // 
            this.nameDataGridViewTextBoxColumn.DataPropertyName = "name";
            this.nameDataGridViewTextBoxColumn.HeaderText = "Name";
            this.nameDataGridViewTextBoxColumn.MinimumWidth = 8;
            this.nameDataGridViewTextBoxColumn.Name = "nameDataGridViewTextBoxColumn";
            this.nameDataGridViewTextBoxColumn.Width = 150;
            // 
            // profilBindingSource
            // 
            this.profilBindingSource.DataMember = "profil";
            this.profilBindingSource.DataSource = this.database1DataSet2;
            // 
            // database1DataSet2
            // 
            this.database1DataSet2.DataSetName = "Database1DataSet2";
            this.database1DataSet2.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.Color.Blue;
            this.button2.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.button2.Location = new System.Drawing.Point(665, 404);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(89, 34);
            this.button2.TabIndex = 20;
            this.button2.Text = "Revenir";
            this.button2.UseVisualStyleBackColor = false;
            // 
            // profilTableAdapter
            // 
            this.profilTableAdapter.ClearBeforeFill = true;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(12, 437);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(271, 80);
            this.label4.TabIndex = 21;
            this.label4.Text = "Répartition salaire\r\nCopyright (c) 2026 Warren Kenji-LWK\r\n\r\nLicensed under the MI" +
    "T License.";
            // 
            // add
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 526);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.idtxt);
            this.Controls.Add(this.pwdtxt);
            this.Controls.Add(this.nametxt);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.profil);
            this.Controls.Add(this.panel1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "add";
            this.Text = "Ajoute d\'utilisateur";
            this.Load += new System.EventHandler(this.add_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.profil)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.profilBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.database1DataSet2)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label titrelbl;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.TextBox idtxt;
        private System.Windows.Forms.TextBox pwdtxt;
        private System.Windows.Forms.TextBox nametxt;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.DataGridView profil;
        private System.Windows.Forms.Button button2;
        private Database1DataSet2 database1DataSet2;
        private System.Windows.Forms.BindingSource profilBindingSource;
        private Database1DataSet2TableAdapters.profilTableAdapter profilTableAdapter;
        private System.Windows.Forms.DataGridViewTextBoxColumn idnameDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn pwdDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn nameDataGridViewTextBoxColumn;
        private System.Windows.Forms.Label label4;
    }
}