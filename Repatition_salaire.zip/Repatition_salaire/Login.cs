﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;
using System.IO;

namespace Repatition_salaire
{
    public partial class Login : Form
    {
        public Login()
        {
            InitializeComponent();
        }

        private bool isValid()
        {
            if (idtxt.Text.TrimStart() == string.Empty)
            {
                MessageBox.Show("enter valid user name", "error");
                return false;
            }
            else if (pwdtxt.Text.TrimStart() == string.Empty)
            {
                MessageBox.Show("enter valid password", "error");
                return false;
            }
            return true;
        }
        public static string IdProfilConnecte;

        private void loginbtn_Click(object sender, EventArgs e)
        {
            if (isValid())

            {
                string databasePath = Path.Combine(Application.StartupPath, "Database1.mdf");

                string connectionString =
                $@"Data Source=(LocalDB)\MSSQLLocalDB;
AttachDbFilename={databasePath};
Integrated Security=True";
                using (SqlConnection conn = new SqlConnection(connectionString))
                {
                    string query = "SELECT * FROM profil WHERE Idname = '" + idtxt.Text.Trim() + "'AND pwd = '" + pwdtxt.Text.Trim() + "'";
                    SqlDataAdapter sda = new SqlDataAdapter(query, conn);
                    DataTable dta = new DataTable();
                    sda.Fill(dta);
                    if (dta.Rows.Count == 1)
                    {

                        Login.IdProfilConnecte =
                        Convert.ToString(dta.Rows[0]["Idname"]);

                        dashbord dashbord = new dashbord();
                        this.Hide();
                        dashbord.Show();


                        
                    }
                    else
                    {
                        MessageBox.Show("Invalid username or password", "error");
                    }
                }
            }
            
        }

        private void resetbtn_Click(object sender, EventArgs e)
        {
            idtxt.Clear();
            pwdtxt.Clear();
        }

        private void add_Click(object sender, EventArgs e)
        {
            try
            {
                string databasePath = Path.Combine(Application.StartupPath, "Database1.mdf");

                string connectionString =
                $@"Data Source=(LocalDB)\MSSQLLocalDB;
AttachDbFilename={databasePath};
Integrated Security=True";
                SqlConnection con = new SqlConnection(connectionString);

                string requete = "INSERT INTO profil (Idname, pwd) VALUES (@Idname, @pwd)";

                SqlCommand cmd = new SqlCommand(requete, con);

                cmd.Parameters.AddWithValue("@Idname", idtxt.Text);
                cmd.Parameters.AddWithValue("@pwd", pwdtxt.Text);

                con.Open();
                cmd.ExecuteNonQuery();
                con.Close();

                MessageBox.Show("Compte enregistré avec succès !");

                add add = new add();
                this.Hide();
                add.Show();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }


        private void exitbtn_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void changebtn_Click(object sender, EventArgs e)
        {
            if (isValid())
            {
                string databasePath = Path.Combine(Application.StartupPath, "Database1.mdf");

                string connectionString =
                $@"Data Source=(LocalDB)\MSSQLLocalDB;
AttachDbFilename={databasePath};
Integrated Security=True";
                using (SqlConnection conn = new SqlConnection(connectionString))
                {
                    string query = "SELECT * FROM profil WHERE Idname = '" + idtxt.Text.Trim() + "'AND pwd = '" + pwdtxt.Text.Trim() + "'";
                    SqlDataAdapter sda = new SqlDataAdapter(query, conn);
                    DataTable dta = new DataTable();
                    sda.Fill(dta);
                    if (dta.Rows.Count == 1)
                    {
                        Login.IdProfilConnecte =
                        Convert.ToString(dta.Rows[0]["Idname"]);

                        changepwd changepwd = new changepwd();
                        this.Hide();
                        changepwd.Show();
                    }
                    else
                    {
                        MessageBox.Show("Invalid username or password", "error");
                    }
                }
            }
        }

        
    }
}
